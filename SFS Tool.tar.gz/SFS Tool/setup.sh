#!/bin/bash
VERDE='\033[0;32m'
ROJO='\033[0;31m'
NC='\033[0m'

echo -e "${VERDE}--- SFS TOOL: Instalador Universal ---${NC}"

if command -v apt &> /dev/null; then
    INSTALLER="apt install -y"
    UPDATE="apt update -y"
    PKGS="android-tools-adb android-tools-fastboot heimdall-flash g++ build-essential"
elif command -v pacman &> /dev/null; then
    INSTALLER="pacman -S --noconfirm"
    UPDATE="pacman -Sy"
    PKGS="android-tools heimdall gcc"
elif command -v dnf &> /dev/null; then
    INSTALLER="dnf install -y"
    UPDATE="dnf check-update"
    PKGS="android-tools heimdall-flash gcc-c++"
else
    echo -e "${ROJO}Error: No se detecto un gestor compatible.${NC}"; exit 1
fi

if [[ $EUID -ne 0 ]]; then
   echo -e "${ROJO}Error: Ejecutame con sudo.${NC}"; exit 1
fi

echo "Actualizando e instalando..."
$UPDATE > /dev/null
$INSTALLER $PKGS > /dev/null

echo "Compilando SFS TOOL v5.4..."
g++ sfs.cpp -o sfs
if [ $? -eq 0 ]; then
    chmod +x sfs
    echo -e "${VERDE}[+] Listo. Ejecuta ./sfs${NC}"
else
    echo -e "${ROJO}[!] Error al compilar.${NC}"
fi
