#include <iostream>
#include <string>
#include <vector>
#include <termios.h>
#include <unistd.h>
#include <array>
#include <algorithm>
#include <cstdio>
#include <fstream>

struct termios t_orig;

void restaurar_terminal() {
    tcsetattr(STDIN_FILENO, TCSANOW, &t_orig);
}

std::string ejecutar(const char* cmd) {
    std::array<char, 128> buffer;
    std::string resultado;
    FILE* pipe = popen(cmd, "r");
    if (!pipe) return "Error.";
    while (fgets(buffer.data(), buffer.size(), pipe) != nullptr) {
        resultado += buffer.data();
    }
    pclose(pipe);
    return resultado;
}

int getch() {
    struct termios newt;
    int ch;
    tcgetattr(STDIN_FILENO, &newt);
    newt.c_lflag &= ~(ICANON | ECHO);
    tcsetattr(STDIN_FILENO, TCSANOW, &newt);
    ch = getchar();
    if (ch == 27) {
        getchar(); 
        switch(getchar()) {
            case 'A': ch = 65; break;
            case 'B': ch = 66; break;
        }
    }
    restaurar_terminal();
    return ch;
}

void limpiar_pantalla() {
    if (system("clear") == -1);
}

void escanear_scatter(std::string ruta) {
    std::ifstream archivo(ruta);
    if (!archivo.is_open()) {
        std::cout << "\033[1;31m[!] Error al abrir el Scatter.\033[0m" << std::endl;
        return;
    }
    std::cout << "\033[1;32m--- MAPA DE MEMORIA MTK (SCATTER) ---\033[0m\n" << std::endl;
    std::string linea;
    int contador = 0;
    while (std::getline(archivo, linea)) {
        if (linea.find("partition_name:") != std::string::npos) {
            size_t pos = linea.find(":");
            std::string nombre = linea.substr(pos + 1);
            nombre.erase(std::remove_if(nombre.begin(), nombre.end(), isspace), nombre.end());
            std::cout << "[" << ++contador << "] " << nombre << "  ";
            if (contador % 4 == 0) std::cout << std::endl;
        }
    }
    archivo.close();
}

void imprimir_tabla_dispositivo() {
    limpiar_pantalla();
    std::cout << "\033[1;35m[SFS] IMPRIMIR TABLA DE PARTICIONES (SAMSUNG/MTK)\033[0m" << std::endl;
    std::cout << "Escaneando protocolos...\n" << std::endl;
    
    std::string res_fb = ejecutar("fastboot devices");
    if (!res_fb.empty()) {
        std::cout << "\033[1;32m[+] Fastboot Detectado.\033[0m" << std::endl;
        std::cout << ejecutar("fastboot getvar all 2>&1 | grep 'partition'");
    } else {
        std::cout << "\033[1;33m[!] Probando modo Download (Heimdall)...\033[0m" << std::endl;
        std::string res_h = ejecutar("heimdall print-pit --no-reboot 2>&1");
        std::cout << res_h << std::endl;
    }
    std::cout << "\nPresiona una tecla...";
    getch();
}

void tty_manual() {
    limpiar_pantalla();
    std::cout << "\033[1;37;44m SFS RECUPERATION MANUAL - TTY \033[0m" << std::endl;
    std::cout << "Escribe 'help' para comandos o 'exit' para salir.\n" << std::endl;
    std::string cmd;
    while(true) {
        std::cout << "\033[1;32mSFS_RECUPERATION>\033[0m ";
        std::getline(std::cin, cmd);
        if (cmd == "exit") break;
        if (cmd == "help") {
            std::cout << "\n sfs-info / sfs-wipe (EXP) / sfs-boot / sfs-credits\n";
        } else if (cmd == "sfs-credits") {
            std::cout << "\n\033[1;36m       SFS TOOL - Desarrollado por Thiago\033[0m" << std::endl;
            std::cout << "\033[1;32m   [+] Especialista en Recuperacion de Hardware\033[0m" << std::endl;
            std::cout << "\033[1;34m   [+] Laboratorio Lanus - 2026\033[0m\n" << std::endl;
        } else if (cmd == "sfs-wipe") {
            std::cout << "\033[1;31m[!] COMANDO EXPERIMENTAL - NO TESTEADO\033[0m\n";
            ejecutar("fastboot erase cache && fastboot format cache");
            ejecutar("fastboot erase userdata && fastboot format userdata");
        } else {
            std::cout << ejecutar(cmd.c_str()) << std::endl;
        }
    }
}

void menu_emergencia() {
    std::vector<std::string> opciones = {
        "Borrar FRP (NO TESTEADO)", 
        "Samsung Reactivation Lock (EXPERIMENTAL)", 
        "SFS RECUPERATION MANUAL", 
        "Volver"
    };
    size_t sel = 0;
    while(true) {
        limpiar_pantalla();
        std::cout << "\033[1;31m!!! MENU DE EMERGENCIA !!!\033[0m\n" << std::endl;
        for (size_t i = 0; i < opciones.size(); ++i) {
            if (i == sel) std::cout << " \033[1;31m=> " << opciones[i] << " <=\033[0m" << std::endl;
            else std::cout << "    " << opciones[i] << std::endl;
        }
        int t = getch();
        if (t == 65) sel = (sel > 0) ? sel - 1 : opciones.size() - 1;
        else if (t == 66) sel = (sel < opciones.size() - 1) ? sel + 1 : 0;
        else if (t == 10) {
            if (opciones[sel] == "Volver") break;
            if (opciones[sel] == "SFS RECUPERATION MANUAL") tty_manual();
            if (opciones[sel].find("NO TESTEADO") != std::string::npos || opciones[sel].find("EXPERIMENTAL") != std::string::npos) {
                std::cout << "\033[1;33m[!] ADVERTENCIA: Esta funcion no ha sido probada aun.\033[0m\n";
                if (opciones[sel] == "Borrar FRP (NO TESTEADO)") {
                    std::cout << "Ejecutando secuencia de borrado...\n";
                    ejecutar("fastboot erase frp 2>&1");
                }
                getch();
            }
        }
    }
}

void mostrar_menu(size_t seleccion, const std::vector<std::string>& opciones) {
    limpiar_pantalla();
    std::cout << "\033[1;36m===============================\033[0m" << std::endl;
    std::cout << "\033[1;36m       SFS TOOL - v5.4         \033[0m" << std::endl;
    std::cout << "\033[1;36m===============================\033[0m" << std::endl;
    for (size_t i = 0; i < opciones.size(); ++i) {
        if (i == seleccion) std::cout << " \033[1;33m=> " << opciones[i] << " <=\033[0m" << std::endl;
        else std::cout << "    " << opciones[i] << std::endl;
    }
}

int main() {
    tcgetattr(STDIN_FILENO, &t_orig);
    std::vector<std::string> opciones = {
        "Detectar Dispositivos",
        "Manipular Particiones (EXPERIMENTAL)",
        "Imprimir PIT/Scatter (ESTABLE)",
        "Reiniciar a Download (Samsung)",
        "MENU DE EMERGENCIA",
        "Salir"
    };
    
    size_t seleccion = 0;
    bool ejecutando = true;

    while (ejecutando) {
        mostrar_menu(seleccion, opciones);
        int tecla = getch();
        if (tecla == 65) seleccion = (seleccion > 0) ? seleccion - 1 : opciones.size() - 1;
        else if (tecla == 66) seleccion = (seleccion < opciones.size() - 1) ? seleccion + 1 : 0;
        else if (tecla == 10) {
            if (opciones[seleccion] == "Salir") ejecutando = false;
            else if (opciones[seleccion] == "MENU DE EMERGENCIA") menu_emergencia();
            else if (opciones[seleccion] == "Imprimir PIT/Scatter (ESTABLE)") imprimir_tabla_dispositivo();
            else if (opciones[seleccion] == "Detectar Dispositivos") {
                limpiar_pantalla();
                std::cout << ejecutar("adb devices && fastboot devices") << std::endl;
                getch();
            }
            else if (opciones[seleccion] == "Manipular Particiones (EXPERIMENTAL)") {
                limpiar_pantalla();
                std::cout << "Arrastra el scatter: ";
                std::string r; std::getline(std::cin, r);
                r.erase(std::remove(r.begin(), r.end(), '\''), r.end());
                r.erase(std::remove(r.begin(), r.end(), '\"'), r.end());
                escanear_scatter(r);
                getch();
            }
            else if (opciones[seleccion] == "Reiniciar a Download (Samsung)") {
                ejecutar("adb reboot download 2>/dev/null");
            }
        }
    }
    restaurar_terminal();
    limpiar_pantalla();
    return 0;
}
